<div>
<h1>Tudo Concurso</h1>
<p>Auxiliar estudantes de provas de concursos públicos a manterem-se informados acerca das provas de seu interesse com editais, períodos de inscrições, gabaritos das provas e as matérias mais presentes nas provas.</p>
</div>
<div>
<p>
Tarefas: 
<p>☑️ - Feitos | ⬜ - A fazer | 2 Semanas de estima por tarefa</p>
</p>
    <div>
    <p>⬜: Preparação do Ambiente de programação</p>
    <p>⬜: Iniciaçização do repositorios de versão (GIT)</p>
    <p>⬜: Criando o metodo de persitencia com o banco</p>
    <p>⬜: Programação do projeto MVP</p>
    <p>⬜: Teste finais (Unitarios, Integração, Ambiente)</p>
    </div>
</div>

